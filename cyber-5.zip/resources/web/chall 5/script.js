// Matrix rain effect (version simplifiée)
function createMatrixRain() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '-1';
    canvas.style.pointerEvents = 'none';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    document.body.appendChild(canvas);
    
    const characters = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const columns = Math.floor(canvas.width / 20);
    const drops = new Array(columns).fill(0);
    
    function draw() {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#00ff41';
        ctx.font = '15px monospace';
        
        for (let i = 0; i < drops.length; i++) {
            const text = characters[Math.floor(Math.random() * characters.length)];
            const x = i * 20;
            const y = drops[i] * 20;
            
            ctx.fillText(text, x, y);
            
            if (y > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }
    
    setInterval(draw, 35);
    
    // Redimensionnement
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// Navigation fluide
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animation des statistiques
function animateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const finalText = entry.target.textContent;
                entry.target.textContent = '0';
                
                if (finalText.includes('%')) {
                    animateNumber(entry.target, 0, parseFloat(finalText), '%');
                } else if (finalText.includes('s')) {
                    entry.target.textContent = finalText;
                } else {
                    entry.target.textContent = finalText;
                }
            }
        });
    });
    
    statNumbers.forEach(stat => observer.observe(stat));
}

function animateNumber(element, start, end, suffix = '') {
    const duration = 2000;
    const increment = end / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = current.toFixed(1) + suffix;
    }, 16);
}

// Gestion du formulaire
document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Simulation d'envoi
    const button = this.querySelector('button');
    const originalText = button.textContent;
    
    button.textContent = 'TRANSMISSION...';
    button.style.background = '#ff6600';
    
    setTimeout(() => {
        button.textContent = 'MESSAGE CHIFFRÉ ✓';
        button.style.background = '#00ff41';
        
        setTimeout(() => {
            button.textContent = originalText;
            button.style.background = '';
            this.reset();
        }, 2000);
    }, 1500);
});

// Effet de glitch aléatoire sur le titre
function randomGlitch() {
    const title = document.querySelector('.glitch');
    if (title && Math.random() < 0.1) {
        title.style.animation = 'none';
        setTimeout(() => {
            title.style.animation = 'glitch 2s infinite';
        }, 100);
    }
}

// Console Easter Egg
console.log(`
%c🔍 CYBERMATRIX CSS INSPECTOR CHALLENGE 🔍
%cForensics Mode: ACTIVE
%cHidden Elements Detected: YES
%cDOM Investigation Required
%cHint: Look for elements with 'display: none' property...
%cTarget: .hidden-flag-container
%cAction: Change display property to 'block'
`, 
'color: #00ffff; font-size: 16px; font-weight: bold;',
'color: #00ff41; font-size: 12px;',
'color: #ffaa00; font-size: 12px;',
'color: #ff0080; font-size: 12px;',
'color: #00ffff; font-size: 12px; font-style: italic;',
'color: #00ff41; font-size: 12px; font-family: monospace;',
'color: #ff0080; font-size: 12px; font-family: monospace;'
);

// Curseur personnalisé
document.addEventListener('mousemove', (e) => {
    const cursor = document.querySelector('.cursor');
    if (!cursor) {
        const newCursor = document.createElement('div');
        newCursor.className = 'cursor';
        newCursor.style.cssText = `
            position: fixed;
            width: 20px;
            height: 20px;
            background: rgba(0, 255, 65, 0.5);
            border: 1px solid #00ff41;
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            mix-blend-mode: difference;
        `;
        document.body.appendChild(newCursor);
    }
    
    const cursor2 = document.querySelector('.cursor');
    cursor2.style.left = e.clientX - 10 + 'px';
    cursor2.style.top = e.clientY - 10 + 'px';
});

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    createMatrixRain();
    animateStats();
    
    // Glitch aléatoire toutes les 5 secondes
    setInterval(randomGlitch, 5000);
    
    // Effet de démarrage
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});